import { Routes } from '@angular/router';
import { EmployeeComponent } from './component/employee/employee.component';

export const routes: Routes = [
    {
        path:'',component:EmployeeComponent
    }
];
