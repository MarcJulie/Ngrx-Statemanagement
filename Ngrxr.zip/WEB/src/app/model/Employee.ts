export interface Employee{
    id:number;
    name:string;
    doj:Date;
    role:string;
    salary:number;
}