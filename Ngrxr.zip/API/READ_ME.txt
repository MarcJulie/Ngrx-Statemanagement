start command : 

npm start